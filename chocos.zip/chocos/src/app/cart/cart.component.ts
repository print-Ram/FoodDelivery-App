import { AfterViewInit, Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { Foods } from '../models/food';
import { CartService } from '../service/cart/cart.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

declare var Razorpay: any;
declare var google: any;

@Component({
  selector: 'app-cart',
  standalone: false,
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent implements OnInit,AfterViewInit {
  cartItems: Foods[] = [];
  groupedCartItems: any[] = [];
  
  constructor(
    private cartService: CartService,
    private http: HttpClient,
    private router: Router,
    private modalService: NgbModal
  ) {
    const storedItems = sessionStorage.getItem('cart');
    this.cartItems = storedItems ? JSON.parse(storedItems) : [];
  }

  @ViewChild('orderSuccess') orderSuccess!: TemplateRef<any>;
  @ViewChild('paymentFailed') paymentFailed!: TemplateRef<any>;

  ngOnInit(): void {
    this.cartService.loadCart();
    this.loadCart();
  }

  loadCart(): void {
    this.cartItems = this.cartService.getCartItems();
    this.groupCartItems();
    this.getFullShippingAddress();  

  }

  groupCartItems(): void {
    const grouped = new Map<string, any>();
    for (const item of this.cartItems) {
      if (grouped.has(item.product_id)) {
        grouped.get(item.product_id).quantity += 1;
      } else {
        grouped.set(item.product_id, { ...item, quantity: 1 });
      }
    }
    this.groupedCartItems = Array.from(grouped.values());
  }

  increment(item: Foods): void {
    this.cartService.addToCart(item);
    this.loadCart();
  }

  decrement(item: Foods): void {
    this.cartService.removeFromCart(item.product_id);
    this.loadCart();
  }

  getTotalPrice(items: { price: number; quantity: number }[]): number {
  return items.reduce((total, item) => total + (item.price * item.quantity), 0);
}

getCartTotal(): number {
  return this.getTotalPrice(this.groupedCartItems);
}


building: string = '';
pincode: string = '';
street: string = '';
city: string = '';
shippingAddress: string = '';
address : boolean = false;
buy : boolean = true;


ngAfterViewInit() {
    const input = document.getElementById("autocomplete") as HTMLInputElement;
    if (!input) return;

    const autocomplete = new google.maps.places.Autocomplete(input, {
      types: ["geocode"],
      componentRestrictions: { country: "in" }
    });

    autocomplete.addListener("place_changed", () => {
      const place = autocomplete.getPlace();
      if (!place || !place.address_components) return;

      this.fillAddressFields(place);
    });
  }

  fillAddressFields(place: any) {
    const components = place.address_components;

    this.building = this.getComponent(components, 'street_number') || this.getComponent(components, 'premise') || '';
    this.street = this.getComponent(components, 'route') || this.getComponent(components, 'sublocality') || '';
    this.pincode = this.getComponent(components, 'postal_code') || '';
    this.city = this.getComponent(components, 'locality') || this.getComponent(components, 'administrative_area_level_2') || '';
  }

  getComponent(components: any[], type: string): string | null {
    const comp = components.find((c) => c.types.includes(type));
    return comp ? comp.long_name : null;
  }

  getFullShippingAddress(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject("Geolocation not supported");
        return;
      }

      this.address = true;
      this.buy = false;

      navigator.geolocation.getCurrentPosition(
        (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;

          const backendUrl = `https://springboot-app-400542225228.us-central1.run.app/auth/orders/get-address?lat=${lat}&lng=${lng}`;

          this.http.get<any>(backendUrl).subscribe(
            (res) => {
              if (res.results && res.results.length > 0) {
                const place = res.results[0];
                this.fillAddressFields(place); // same function works for backend geocode response if structure matches
                resolve();
              } else {
                reject("No address found");
              }
            },
            () => reject("Failed to fetch location from backend")
          );
        },
        () => reject("Unable to detect location")
      );
    });
  }



buyNow(): void {
  this.address = false;
  this.buy = false;

  const token = sessionStorage.getItem('token');
  const tokenUserId = sessionStorage.getItem('userId'); // ensure this is set during login

  const amount = this.getTotalPrice(this.groupedCartItems);

  // ✅ Combine all address parts into a single string
  const shippingAddress = `${this.building}, ${this.street}, ${this.city} - ${this.pincode}`;

  this.http.post<any>(
    'https://springboot-app-400542225228.us-central1.run.app/auth/orders/create-payment',
    { amount },
    { headers: { Authorization: `Bearer ${token}` } }
  ).subscribe({
    next: (response) => {
      const options = {
        key: 'rzp_test_ZFRZgGGwyk6bgC',
        amount: response.amount,
        currency: response.currency,
        order_id: response.id,
        method: { upi: true },
        upi: { flow: 'intent' },
        handler: (paymentResponse: any) => {
          const orderPayload = {
            items: this.groupedCartItems,
            totalPrice: amount,
            status: 'CONFIRMED',
            orderDate: new Date().toISOString(),
            shippingAddress
          };

          // ✅ Step 1: Place order
          this.http.post(
            'https://springboot-app-400542225228.us-central1.run.app/auth/orders/place',
            orderPayload,
            {
              headers: { Authorization: `Bearer ${token}` },
              responseType: 'text'
            }
          ).subscribe({
            next: () => {
              // ✅ Step 2: Update user address in profile
              const updatePayload = { address: shippingAddress };

              this.http.put(
                `https://springboot-app-400542225228.us-central1.run.app/auth/users/${tokenUserId}/update`,
                updatePayload,
                {
                  headers: { Authorization: `Bearer ${token}` },
                  responseType: 'text'
                }
              ).subscribe({
                next: () => console.log('User address updated in profile'),
                error: () => console.warn('Failed to update user profile address')
              });

              this.modalService.open(this.orderSuccess);
              sessionStorage.removeItem('cart');
              this.cartService.clearCart();
              this.router.navigate(['/orders']);
            },
            error: () => alert('Order saving failed')
          });
        },
        prefill: {
          name: 'Customer Name',
          email: 'test@example.com',
          contact: '9999999999'
        },
        theme: { color: '#3399cc' }
      };

      const rzp = new Razorpay(options);
      rzp.on('payment.failed', () => {
      this.modalService.open(this.paymentFailed);
      setTimeout(() => {
          this.router.navigate(['/cart']);
      }, 2000); 
    });

      rzp.open();
    },
    error: () => alert('Failed to initiate payment')
  });
}

public goToCart(): void {
  this.router.navigate(['/cart']);
}

goToOrders(): void {
  this.router.navigate(['/orders']);
}

}