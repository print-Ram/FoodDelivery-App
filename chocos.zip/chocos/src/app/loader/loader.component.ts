import { Component, Input } from '@angular/core';
import { LoadingService } from '../loading.service';

@Component({
  selector: 'app-loader',
  standalone: false,
  templateUrl: './loader.component.html',
  styleUrl: './loader.component.css'
})
export class LoaderComponent {

  // @Input() message: string = 'Loading...';

  constructor(public loadingService: LoadingService) {}

}
