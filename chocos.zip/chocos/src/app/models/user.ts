export interface User {
  user_id?: string;
  name?: string;
  email?: string;
  password?: string;
  address?: string;
  contact?: string;
}