import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../service/auth/auth.service';
import { Router } from '@angular/router';
import { LoginComponent } from '../login/login.component';

@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent implements OnInit {
  authForm!: FormGroup;
  errorMessage: string = '';
  isLoading: boolean = false;


  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    this.buildForm();
  }

  showPassword = false;

togglePasswordVisibility(event: MouseEvent) {
  event.stopPropagation();
  this.showPassword = !this.showPassword;
}

  buildForm(): void {
    this.authForm = this.fb.group({
      name: ['', Validators.required],
      contact: ['', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]],
      email: [  ' ', [ Validators.required, Validators.email, Validators.pattern(/^[a-zA-Z0-9._%+-]+@gmail\.com$/) ] ],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  toastMessage: string = '';
  showToast: boolean = false;


  register(): void {
  this.isLoading = true;

  if (!this.authForm.valid) {
    this.isLoading = false;
    return;
  }

  const user = this.authForm.value;

  this.authService.register(user).subscribe({
    next: (res) => {
      const credentials = {
        username: user.email,
        password: user.password
      };

      this.authService.login(credentials).subscribe({
        next: (loginRes) => {
          this.authService.saveToken(loginRes.token);
          const targetRoute = loginRes.role === 'ADMIN' ? '/admin' : '/user';
          this.router.navigateByUrl(targetRoute, { replaceUrl: true });
          this.isLoading = false;
        },
        error: () => {
          this.showToastMessage('Auto-login failed. Please login manually.');
          this.isLoading = false;
        }
      });
    },
    error: (err) => {
      if (err.status === 409) {
        this.showToastMessage('Email already exists');
      } else {
        this.showToastMessage('Registration failed. Please try again.');
      }
      this.isLoading = false;
    }
  });
}

private showToastMessage(message: string): void {
  this.toastMessage = message;
  this.showToast = true;
  setTimeout(() => this.showToast = false, 5000);
}




}
